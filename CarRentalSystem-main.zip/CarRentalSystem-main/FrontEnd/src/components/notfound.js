function NotFound()
{
    return <h1>Resource Not Found!</h1>
}

export default NotFound