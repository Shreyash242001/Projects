function Main(){
return (<div>
<h1>I  am  Sam</h1>
Username  : <input class="form-control"  type={"text"} placeholder="Enter your Username" required></input><br></br>
Password :  
<input type="password" name="" id="input" class="form-control" required="required" title="" placeholder="Enter Password">
</input><br></br>
<button className="btn btn-danger">Submit</button>
</div>)
}

export default Main;