namespace MyApp.Models;

public readonly record struct DeptList(string DNo, string DName);