namespace MyApp.Models;

public readonly record struct EmpList(string EId, string EName, string Ages, string Salary, string DId);