using MyApp.Models;
using Microsoft.AspNetCore.Mvc;
namespace MyApp.Controllers;

public class HomeController : Controller
{
    public IActionResult Worker([FromServices] SiteDbContext site)
    {
        var selection = from cust in site.Employee
                        //where double.Parse(cust.Sal) > 20000
                        select new EmpList 
                        {
                            EId = cust.Id,
                            EName = cust.EmpName,
                            Ages = cust.Age,
                            Salary = cust.Sal,
                            DId = cust.DeptId
                        };
        return View(selection.ToList());
    }

    public IActionResult Register()
    {
        return View(new Emp());
    }


    [HttpPost]
    public IActionResult Register([FromServices] SiteDbContext site, Emp input)
    {
        if(ModelState.IsValid)
        {
            //var employee; //= site.Emp.First(e => e.id == input.Id);
            // if(employee is null)
            // {
                var employee = input;
                site.Employee.Add(employee);
            // }
           // employee.Visits.Add(new Emp());
            site.SaveChanges();
            return RedirectToAction("Worker");
        }
        return Register();
    }
    public IActionResult EmployeeRemove()
    {
        return View(new Emp());
    }

    [HttpPost]
    public IActionResult EmployeeRemove([FromServices] SiteDbContext site, Emp input)
    {
        if (ModelState.IsValid)
        {
            var emp = site.Employee.FirstOrDefault(e => e.Id == input.Id);
            if (emp == null)
            {
                // If no employee found, handle the situation here, maybe redirect to a page or return a specific error message
                return NotFound(); // Or another appropriate action
            }
            
            site.Employee.Remove(emp);
            site.SaveChanges();
        }
    
        return RedirectToAction("Worker");
    }

    // public IActionResult EmployeeRemove([FromServices] SiteDbContext site, Emp input)
    // {
    //     if(ModelState.IsValid)
    //     {
    //     var emp = site.Employee.First(e => e.Id == input.Id);
    //     if(emp is null)
    //     {
    //     //         //var employee = input;
    //         return RedirectToPage("EmployeeRemove");
    //         //site.Employee.Remove(input);
    //     }
    //     //    // employee.Visits.Add(new Emp());
    //     site.Employee.Remove(input);
    //     site.SaveChanges();
        
    //     }
    //     return RedirectToAction("Worker");
    // }


//--------------------**************************------------------------------********************************---------------


    public IActionResult DeptRegister([FromServices] SiteDbContext site)
    {
        var selection = from cust in site.Department
                        //where double.Parse(cust.Sal) > 20000
                        select new DeptList 
                        {
                            DNo = cust.Id,
                            DName = cust.DeptName
                        };
        return View(selection.ToList());
    }

    public IActionResult DeptTable()
    {
        return View(new Depts());
    }


    [HttpPost]
    public IActionResult DeptTable([FromServices] SiteDbContext site, Depts input)
    {
        if(ModelState.IsValid)
        {
            //var employee; //= site.Emp.Find(input.Id);
            // if(employee is null)
            // {
                var department = input;
                site.Department.Add(department);
            // }
           // employee.Visits.Add(new Emp());
            site.SaveChanges();
            return RedirectToAction("Worker");
        }
        return DeptTable();
    }

}