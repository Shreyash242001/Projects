using MyApp.Models;


// var builder = WebApplication.CreateBuilder(args);

// builder.Services.AddControllersWithViews();
// builder.Services.AddDbContext<MyApp.Models.SiteDbContext>();

// var app = builder.Build();

// app.UseCors(permissions => permissions.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

// app.UseRouting();
// app.MapDefaultControllerRoute();
// app.Run();


var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();
builder.Services.AddAuthentication()
    .AddCookie(option => option.LoginPath = "/Index");
builder.Services.AddDbContext<MyApp.Models.SiteDbContext>();

var app = builder.Build();
app.UseAuthentication();
app.UseAuthorization();
app.MapRazorPages();
app.MapDefaultControllerRoute();
app.Run();
