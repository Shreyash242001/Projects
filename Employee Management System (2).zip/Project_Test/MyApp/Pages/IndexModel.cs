using System.Security.Claims;

using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyApp.Models;
namespace MyApp.Pages;

public class IndexModel : PageModel
{
    private readonly SiteDbContext shop;

    [BindProperty]
    public Emp Input { get; set; }

    public IndexModel(SiteDbContext db) => shop = db;

    public void OnGet()
    {
        Input = new Emp();
    }

    public async Task<IActionResult> OnPost()
    {
        if(ModelState.IsValid)
        {
        var customer = await shop.Employee.FindAsync(Input.Id);
        if(customer?.Password == Input.Password)
        {
            var identity = new ClaimsIdentity("Emp");
            identity.AddClaim(new Claim(ClaimTypes.Name, Input.Id));
            await HttpContext.SignInAsync(new ClaimsPrincipal(identity));
            return RedirectToAction("Worker");
        }
        }
        ModelState.AddModelError("Login", "Invalid Customer ID or Password");
        return Page();
    }

}